const express = require('express');
const session = require('express-session');
const Keycloak = require('keycloak-connect');
const { ApolloServer, gql } = require('apollo-server-express');
const { Pool } = require('pg');
const cors = require('cors');

// Настройки Keycloak
const memoryStore = new session.MemoryStore();
const keycloak = new Keycloak({ store: memoryStore });

const app = express();
app.use(cors());
app.use(session({
  secret: 'some secret',
  resave: false,
  saveUninitialized: true,
  store: memoryStore
}));
app.use(keycloak.middleware());

// Настройки базы данных
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'DistTasks',
  password: 'Serik2004',
  port: 5432,
});

// GraphQL схема
const typeDefs = gql`
  type Task {
    id: ID!
    description: String!
    user_id: Int!
    userName: String
    created_at: String
  }

  type Query {
    tasks: [Task]
  }

  type Mutation {
    addTask(description: String!, user_id: Int!): Task
  }
`;

// GraphQL резолверы
const resolvers = {
  Query: {
    tasks: async (_, __, { kauth }) => {
      // Проверка аутентификации
      if (!kauth || !kauth.grant) {
        throw new Error('Unauthorized');
      }

      // Получаем задачи из базы данных
      const result = await pool.query('SELECT * FROM tasks');
      return result.rows;
    },
  },
  Mutation: {
    addTask: async (_, { description, user_id }, { kauth }) => {
      // Проверка аутентификации
      if (!kauth || !kauth.grant) {
        throw new Error('Unauthorized');
      }

      // Добавляем новую задачу в базу данных
      const result = await pool.query(
        'INSERT INTO tasks (description, user_id) VALUES ($1, $2) RETURNING *',
        [description, user_id]
      );
      return result.rows[0];
    },
  },
};

// Настройка ApolloServer с передачей токена Keycloak
const server = new ApolloServer({
  typeDefs,
  resolvers,
  context: ({ req }) => {
    return { kauth: req.kauth }; // Передаем токен Keycloak в контекст
  }
});

// Запуск сервера
server.start().then(() => {
  server.applyMiddleware({ app });

  // Пример маршрута для проверки аутентификации
  app.get('/tasks', keycloak.protect(), (req, res) => {
    res.send('Доступ только для авторизованных пользователей');
  });

  app.listen({ port: 3500 }, () =>
    console.log(`Task Service running at http://localhost:3500${server.graphqlPath}`)
  );
});
