import React, { useState } from 'react';

const SignUp = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSignUp = async (e) => {
    e.preventDefault();
    
    try {
      const response = await fetch('http://localhost:3000/graphql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: `
            mutation AddUser($name: String!, $password: String!) {
              addUser(name: $name, password: $password) {
                id
                name
              }
            }
          `,
          variables: { name: username, password },
        }),
      });

      const result = await response.json();

      if (result.errors) {
        setErrorMessage('Ошибка регистрации');
      } else {
        alert('Регистрация успешна!');
      }
    } catch (error) {
      setErrorMessage('Ошибка подключения к серверу');
    }
  };

  return (
    <div>
      <h2>Регистрация</h2>
      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
      <form onSubmit={handleSignUp}>
        <div>
          <label>Имя пользователя</label>
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
        </div>
        <div>
          <label>Пароль</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <button type="submit">Зарегистрироваться</button>
      </form>
    </div>
  );
};

export default SignUp;
