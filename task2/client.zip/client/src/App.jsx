import React, { useEffect, useState } from 'react';
import keycloak from './keycloak';  // Импортируем уже созданный экземпляр Keycloak

const App = () => {
  const [authenticated, setAuthenticated] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [taskDescription, setTaskDescription] = useState('');
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [loadingTasks, setLoadingTasks] = useState(true);
  const [loadingUsers, setLoadingUsers] = useState(true);

  // Инициализация Keycloak и проверка авторизации
  useEffect(() => {
    keycloak.init({ onLoad: 'login-required' }).then((auth) => {
      setAuthenticated(auth);
      if (auth) {
        console.log('Authenticated');
        fetchTasks();
        fetchUsers();

        // Обновляем токен каждые 60 секунд
        const tokenRefreshInterval = setInterval(() => {
          keycloak.updateToken(60).then((refreshed) => {
            if (refreshed) {
              console.log('Token refreshed');
            } else {
              console.warn('Token still valid');
            }
          }).catch((error) => {
            console.error('Failed to refresh token', error);
          });
        }, 60000); // Обновляем токен каждые 60 секунд

        // Очищаем интервал при размонтировании компонента
        return () => clearInterval(tokenRefreshInterval);
      } else {
        console.log('Not authenticated');
      }
    }).catch((err) => {
      console.error('Failed to initialize Keycloak', err);
    });
  }, []);

  // Получение всех задач
  const fetchTasks = async () => {
    try {
      const response = await fetch('http://localhost:3500/graphql', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + keycloak.token
        },
        body: JSON.stringify({
          query: `
            query {
              tasks {
                id
                description
                user_id
                userName
              }
            }
          `,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setTasks(data.data.tasks);
    } catch (error) {
      console.error('Ошибка при получении задач:', error);
    } finally {
      setLoadingTasks(false);  // Скрываем загрузчик после получения данных
    }
  };

  // Получение всех пользователей
  const fetchUsers = async () => {
    try {
      const response = await fetch('http://localhost:3000/graphql', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + keycloak.token
        },
        body: JSON.stringify({
          query: `
            query {
              users {
                id
                name
              }
            }
          `,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setUsers(data.data.users);
    } catch (error) {
      console.error('Ошибка при получении пользователей:', error);
    } finally {
      setLoadingUsers(false);  // Скрываем загрузчик после получения данных
    }
  };

  // Добавление новой задачи
  const addTask = async () => {
    if (!taskDescription || !selectedUserId) {
      alert('Пожалуйста, введите задачу и выберите пользователя.');
      return;
    }

    try {
      const response = await fetch('http://localhost:3500/graphql', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + keycloak.token
        },
        body: JSON.stringify({
          query: `mutation AddTask($description: String!, $user_id: Int!) {
            addTask(description: $description, user_id: $user_id) {
              id
              description
              user_id
              userName
            }
          }`,
          variables: {
            description: taskDescription,
            user_id: selectedUserId,
          },
        }),
      });
      const data = await response.json();
      setTasks((prevTasks) => [...prevTasks, data.data.addTask]);
      setTaskDescription('');
      setSelectedUserId(null);
    } catch (error) {
      console.error('Ошибка при добавлении задачи:', error);
    }
  };

  // Проверка авторизации
  if (!authenticated) {
    return <div>Загрузка...</div>;  // Показываем лоадер, пока идет проверка
  }

  return (
    <div>
      <h1>Привет, {keycloak.tokenParsed?.preferred_username}!</h1>
      <button onClick={() => keycloak.logout()}>Выйти</button>

      <h2>Управление задачами</h2>

      {/* Форма добавления задачи */}
      <div>
        <input
          type="text"
          placeholder="Введите описание задачи"
          value={taskDescription}
          onChange={(e) => setTaskDescription(e.target.value)}
        />
        <select
          value={selectedUserId || ''}
          onChange={(e) => setSelectedUserId(parseInt(e.target.value, 10))}
        >
          <option value="">Выберите пользователя</option>
          {loadingUsers ? (
            <option>Загрузка пользователей...</option>
          ) : (
            users.map((user) => (
              <option key={user.id} value={user.id}>
                {user.name}
              </option>
            ))
          )}
        </select>
        <button onClick={addTask}>Добавить задачу</button>
      </div>

      {/* Вывод задач */}
      {loadingTasks ? (
        <p>Загрузка задач...</p>
      ) : (
        <ul>
          {tasks.map((task) => (
            <li key={task.id}>
              {task.description} (Пользователь: {task.userName})
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default App;

