import React, { useEffect, useState } from 'react';
import keycloak from './keycloak'; // Импортируй заранее созданный экземпляр

const KeycloakAuth = () => {
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => {
    // Инициализируем Keycloak и проверяем авторизацию
    keycloak.init({ onLoad: 'login-required' }).then((auth) => {
      setAuthenticated(auth);
      if (auth) {
        console.log('Authenticated');
        // Обновляем токен каждые 5 секунд или при необходимости
        const tokenRefreshInterval = setInterval(() => {
          keycloak.updateToken(70).then((refreshed) => {
            if (refreshed) {
              console.log('Token refreshed', refreshed);
            } else {
              console.warn('Token not refreshed, valid for ' +
                Math.round(keycloak.tokenParsed.exp + keycloak.timeSkew - new Date().getTime() / 1000) + ' seconds');
            }
          }).catch(() => {
            console.error('Failed to refresh token');
          });
        }, 5000);

        // Очищаем интервал при размонтировании компонента
        return () => clearInterval(tokenRefreshInterval);
      } else {
        console.log('Not authenticated');
      }
    }).catch((err) => {
      console.error('Failed to initialize Keycloak', err);
    });
  }, []);

  if (!authenticated) {
    return <div>Загрузка...</div>;  // Показываем лоадер, пока идет проверка
  }

  return (
    <div>
      <h1>Привет, {keycloak.tokenParsed?.preferred_username}!</h1>
      <button onClick={() => keycloak.logout()}>Выйти</button>
    </div>
  );
};

export default KeycloakAuth;
