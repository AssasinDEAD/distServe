const express = require('express');
const session = require('express-session');
const Keycloak = require('keycloak-connect');
const { ApolloServer, gql } = require('apollo-server-express');
const { Pool } = require('pg');
const cors = require('cors');

// Настройка Keycloak
const memoryStore = new session.MemoryStore();
const keycloak = new Keycloak({ store: memoryStore });

const app = express();
app.use(cors());
app.use(session({
  secret: 'some secret',
  resave: false,
  saveUninitialized: true,
  store: memoryStore
}));
app.use(keycloak.middleware());

// Настройка подключения к базе данных PostgreSQL DistUsers
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'DistUsers',
  password: 'Serik2004',
  port: 5432,
});

// GraphQL схема
const typeDefs = gql`
  type User {
    id: ID!
    name: String!
    age: Int!
    gender: String!
  }

  type Query {
    users: [User]
    user(id: ID!): User
  }

  type Mutation {
    addUser(name: String!, age: Int!, gender: String!): User
    deleteUser(id: ID!): Boolean
    updateUser(id: ID!, name: String, age: Int, gender: String): User
  }
`;

// Резолверы
const resolvers = {
  Query: {
    users: async (_, __, { kauth }) => {
      if (!kauth || !kauth.grant) {
        throw new Error('Unauthorized');
      }
      const result = await pool.query('SELECT * FROM users');
      return result.rows;
    },
    user: async (_, { id }, { kauth }) => {
      if (!kauth || !kauth.grant) {
        throw new Error('Unauthorized');
      }
      const result = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
      return result.rows[0];
    },
  },
  Mutation: {
    addUser: async (_, { name, age, gender }, { kauth }) => {
      if (!kauth || !kauth.grant) {
        throw new Error('Unauthorized');
      }
      const result = await pool.query(
        'INSERT INTO users (name, age, gender) VALUES ($1, $2, $3) RETURNING *',
        [name, age, gender]
      );
      return result.rows[0];
    },
    deleteUser: async (_, { id }, { kauth }) => {
      if (!kauth || !kauth.grant) {
        throw new Error('Unauthorized');
      }
      await pool.query('DELETE FROM users WHERE id = $1', [id]);
      return true;
    },
    updateUser: async (_, { id, name, age, gender }, { kauth }) => {
      if (!kauth || !kauth.grant) {
        throw new Error('Unauthorized');
      }
      const fields = [];
      const values = [id];

      if (name) {
        fields.push(`name = $${fields.length + 2}`);
        values.push(name);
      }

      if (age) {
        fields.push(`age = $${fields.length + 2}`);
        values.push(age);
      }

      if (gender) {
        fields.push(`gender = $${fields.length + 2}`);
        values.push(gender);
      }

      const result = await pool.query(
        `UPDATE users SET ${fields.join(', ')} WHERE id = $1 RETURNING *`,
        values
      );
      return result.rows[0];
    },
  },
};

// Настройка Apollo Server
const server = new ApolloServer({
  typeDefs,
  resolvers,
  context: ({ req }) => {
    return { kauth: req.kauth }; // Передаем токен Keycloak в контекст
  }
});

server.start().then(() => {
  server.applyMiddleware({ app });

  app.listen({ port: 3000 }, () =>
    console.log(`User Service running at http://localhost:3000${server.graphqlPath}`)
  );
});
