const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const BookService = require('./bookService');
const authController = require('./authController');
const authMiddleware = require('./authMiddleware');

const app = express();
app.use(bodyParser.json());
app.use(cookieParser());

app.use('/auth', authController);

app.get('/books/:id', authMiddleware, async (req, res) => {
    try {
        const book = await BookService.getBookById(req.params.id);
        if (book) res.json(book);
        else res.status(404).send('Book not found');
    } catch (error) {
        res.status(500).send('Server error');
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
