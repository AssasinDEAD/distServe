// bookService.js
const db = require('./db');
const redisClient = require('./redisClient');

class BookService {
    static async getBookById(id) {
        return new Promise((resolve, reject) => {
            redisClient.get(`book:${id}`, async (err, cachedData) => {
                if (cachedData) {
                    console.log('Fetching book from cache');
                    this.incrementPopularity(id); 
                    return resolve(JSON.parse(cachedData));
                }

                try {
                    const { rows } = await db.query('SELECT * FROM books WHERE id = $1', [id]);
                    const book = rows[0];

                    if (book) {
                        redisClient.setex(`book:${id}`, 600, JSON.stringify(book)); 
                        this.incrementPopularity(id);
                    }
                    resolve(book);
                } catch (error) {
                    reject(error);
                }
            });
        });
    }

    // Добавление новой книги
    static async addBook(book) {
        const { title, author, price, genre, description } = book;
        const query = `
            INSERT INTO books (title, author, price, genre, description)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *
        `;

        try {
            const { rows } = await db.query(query, [title, author, price, genre, description]);
            const newBook = rows[0];
            redisClient.setex(`book:${newBook.id}`, 600, JSON.stringify(newBook));
            return newBook;
        } catch (error) {
            throw error;
        }
    }

    // Обновление данных книги
    static async updateBook(id, updatedFields) {
        const { title, author, price, genre, description } = updatedFields;
        const query = `
            UPDATE books SET
            title = COALESCE($1, title),
            author = COALESCE($2, author),
            price = COALESCE($3, price),
            genre = COALESCE($4, genre),
            description = COALESCE($5, description)
            WHERE id = $6
            RETURNING *
        `;

        try {
            const { rows } = await db.query(query, [title, author, price, genre, description, id]);
            const updatedBook = rows[0];
            if (updatedBook) {
                redisClient.setex(`book:${id}`, 600, JSON.stringify(updatedBook)); 
            }
            return updatedBook;
        } catch (error) {
            throw error;
        }
    }

    static async deleteBook(id) {
        const query = `DELETE FROM books WHERE id = $1`;
        try {
            await db.query(query, [id]);
            redisClient.del(`book:${id}`);
            redisClient.zrem("popular_books", id);
        } catch (error) {
            throw error;
        }
    }

    static incrementPopularity(id) {
        redisClient.zincrby("popular_books", 1, id);
    }

    // Получение списка популярных книг
    static async getPopularBooks(limit = 10) {
        return new Promise((resolve, reject) => {
            redisClient.zrevrange("popular_books", 0, limit - 1, 'WITHSCORES', (err, result) => {
                if (err) return reject(err);
                resolve(result);
            });
        });
    }
}

module.exports = BookService;
