// authMiddleware.js
const SessionService = require('./sessionService');

async function authMiddleware(req, res, next) {
    const sessionId = req.cookies.sessionId || req.headers['x-session-id']; // Получаем sessionId из cookie или заголовка

    if (!sessionId) {
        return res.status(401).json({ message: 'Unauthorized: Session ID is missing' });
    }

    try {
        const userId = await SessionService.getSession(sessionId);
        if (!userId) {
            return res.status(401).json({ message: 'Unauthorized: Session expired or invalid' });
        }
        
        req.userId = userId; // Добавляем userId в запрос для использования в обработчиках маршрутов
        next();
    } catch (error) {
        res.status(500).send('Server error');
    }
}

module.exports = authMiddleware;
