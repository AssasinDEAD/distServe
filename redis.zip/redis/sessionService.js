const { v4: uuidv4 } = require('uuid');
const redisClient = require('./redisClient');

const SESSION_TTL = 1800;

class SessionService {
   
    static async createSession(userId) {
        const sessionId = uuidv4();
        await redisClient.setex(`session:${sessionId}`, SESSION_TTL, userId);
        return sessionId;
    }

    static async getSession(sessionId) {
        return new Promise((resolve, reject) => {
            redisClient.get(`session:${sessionId}`, (err, userId) => {
                if (err) return reject(err);
                if (userId) {
                    redisClient.expire(`session:${sessionId}`, SESSION_TTL);
                    resolve(userId);
                } else {
                    resolve(null);
                }
            });
        });
    }

    static async deleteSession(sessionId) {
        return new Promise((resolve, reject) => {
            redisClient.del(`session:${sessionId}`, (err) => {
                if (err) return reject(err);
                resolve();
            });
        });
    }
}

module.exports = SessionService;
